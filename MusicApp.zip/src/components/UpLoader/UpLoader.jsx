import React, { useState } from 'react';
import axios from 'axios';

const UpLoader = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleUpload = async () => {
    if (selectedFile) {
      setUploading(true);

      try {
        const formData = new FormData();
        formData.append('musicFile', selectedFile);

        await axios.post('http://localhost:5000/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        setUploading(false);
        setSelectedFile(null);
      } catch (error) {
        console.error('Error uploading file:', error);
        setUploading(false);
      }
    }
  };

  return (
    <div className="music-upload-form">
      <label htmlFor="fileInput">Choose a music file:</label>
      <input
        type="file"
        id="fileInput"
        accept=".mp3, .wav"
        onChange={handleFileChange}
      />
      <p>Selected File: {selectedFile ? selectedFile.name : 'None'}</p>
      <button onClick={handleUpload} disabled={!selectedFile || uploading}>
        {uploading ? 'Uploading...' : 'Upload'}
      </button>
      {uploading && <div className="upload-progress">Uploading...</div>}
    </div>
  );
};

export default UpLoader;
